## Bookstore ##

**Bookstore** is a simple web application which includes and Express RESTful API server and a front end in AngularJS

The video tutorial that goes with this project can be found here
[https://www.youtube.com/watch?v=eB9Fq9I5ocs](https://www.youtube.com/watch?v=eB9Fq9I5ocs "https://www.youtube.com/watch?v=eB9Fq9I5ocs")

## Usage ##
Just clone or download and run **npm install** and then **node app** to start

##Notes##
The Genres Angular controller is blank on purpose. This is for you to try and come up with after watching the video. It may be added in the future

