# Title here

<br/><br/>

### One Paragraph Explainer

Text

<br/><br/>

### Code Example – explanation

```javascript
code here
```

<br/><br/>

### Code Example – another

```javascript
code here
```

<br/><br/>

### Blog Quote: "Title"

 From the blog, pouchdb.com ranked 11 for the keywords “Node Promises”

 > …text here

<br/><br/>

 ### Example: Complex methods analysis with CodeClimate (commercial)

![alt text](https://github.com/i0natan/nodebestpractices/blob/master/assets/images/codeanalysis-climate-complex-methods.PNG "Complex methods analysis")

### Example: Code analysis trends and history with CodeClimate (commercial)

![alt text](https://github.com/i0natan/nodebestpractices/blob/master/assets/images/codeanalysis-climate-history.PNG "Code analysis history")

### Example: Code analysis summary and trends with SonarQube (commercial)

![alt text](https://github.com/i0natan/nodebestpractices/blob/master/assets/images/codeanalysis-sonarqube-dashboard.PNG "Code analysis history")


<br/><br/>
