module.exports = {
  web: {}
};
