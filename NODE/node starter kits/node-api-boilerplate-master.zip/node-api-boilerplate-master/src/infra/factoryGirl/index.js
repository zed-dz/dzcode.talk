module.exports = {
  FactoriesLoader: require('./FactoriesLoader')
};
