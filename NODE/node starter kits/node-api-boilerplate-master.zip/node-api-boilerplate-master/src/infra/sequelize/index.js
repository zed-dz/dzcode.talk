module.exports = {
  ModelsLoader: require('./ModelsLoader')
};
