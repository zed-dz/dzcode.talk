module.exports = {
  GetAllUsers: require('./GetAllUsers'),
  CreateUser: require('./CreateUser'),
  GetUser: require('./GetUser'),
  UpdateUser: require('./UpdateUser'),
  DeleteUser: require('./DeleteUser')
};
