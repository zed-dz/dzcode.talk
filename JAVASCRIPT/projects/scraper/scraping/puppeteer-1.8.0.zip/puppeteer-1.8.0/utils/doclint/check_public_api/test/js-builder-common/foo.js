class A {
  constructor(delegate) {
    this.property1 = 1;
    this._property2 = 2;
  }

  get getter() {
    return null;
  }

  async method(foo, bar) {
  }
}

A.Events = {
  AnEvent: 'anevent'
};
