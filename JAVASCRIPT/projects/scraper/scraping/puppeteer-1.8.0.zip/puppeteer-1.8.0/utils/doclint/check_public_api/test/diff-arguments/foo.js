class Foo {
  foo(arg1, arg3 = {}) {
  }

  test(...filePaths) {
  }

  bar({visibility}) {
  }
}
