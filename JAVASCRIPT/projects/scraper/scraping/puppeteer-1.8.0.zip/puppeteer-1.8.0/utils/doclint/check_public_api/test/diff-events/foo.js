class Foo {
}

Foo.Events = {
  Start: 'start',
  Finish: 'finish',
};
