import num from './es6module.js';
window.__es6injected = num;