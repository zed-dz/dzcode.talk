# Robots Exclusion Protocol Internet Draft (I-D)

The file in this directory is the working copy of the file submitted to IETF for
standardization.

It is published at https://tools.ietf.org/html/draft-rep-wg-topic

**Do not edit files in this folder, we are not accepting reviews.** Instead, get
in touch with the authors.
