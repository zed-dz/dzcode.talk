### Random Web-Development questions I faced or collected from discussion with others ( Slack Group / Facebook Group )

