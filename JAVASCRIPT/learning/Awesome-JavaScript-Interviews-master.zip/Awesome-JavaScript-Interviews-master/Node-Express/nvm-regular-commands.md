At any given time you can switch to another with use:

nvm use 0.12