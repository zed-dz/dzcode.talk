### A challenging case or assignment or technical problem you have solved
