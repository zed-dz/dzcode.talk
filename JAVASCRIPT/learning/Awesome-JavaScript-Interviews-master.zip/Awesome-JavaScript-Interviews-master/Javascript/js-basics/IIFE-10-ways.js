~function () {console.log("Hi I'm IIFE 1")}();
!function () {console.log("Hi I'm IIFE 2")}();
+function () {console.log("Hi I'm IIFE 3")}();
-function () {console.log("Hi I'm IIFE 4")}();
(function () {console.log("Hi I'm IIFE 5")}())
var i = function(){console.log("Hi I'm IIFE 6")}();
true && function(){console.log("Hi I'm IIFE 7")}();
0, function(){console.log("Hi I'm IIFE 8")}();
new function(){console.log("Hi I'm IIFE 9")};
new function(){console.log("Hi I'm IIFE 10")}();
