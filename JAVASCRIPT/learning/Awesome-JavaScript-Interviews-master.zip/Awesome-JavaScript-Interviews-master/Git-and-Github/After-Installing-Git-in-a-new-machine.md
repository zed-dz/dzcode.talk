# Steps to follow after Installling Git for the very first time into a new machine

## $ sudo add-apt-repository ppa:git-core/ppa

## $ sudo apt-get update
## $ sudo apt-get install git

http://tecadmin.net/install-git-on-ubuntu/# - installing git only with the below command

## sudo apt-get install git

Then run the below commands which are one time only – that is after git is installed for the first time in a machine.  So I will need to do the same each time I set up a new Cloud based IDE for the first time.

## git config --global user.name "Rohan Paul"

## git config --global user.email actual-email@gmail.com

## git config --global push.default matching
