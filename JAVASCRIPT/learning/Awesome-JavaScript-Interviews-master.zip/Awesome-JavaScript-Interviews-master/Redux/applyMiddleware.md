### Redux is a small library. And exactly how small is it. [Its just 5 methods](https://github.com/reduxjs/redux/tree/master/src)

### applyMiddleware()

### bindActionCreators()

### combineReducers()

### compose()

### createStore()

So here, lets understand the `applyMiddleware()` function. The official dox is [here](https://redux.js.org/api/applymiddleware)
