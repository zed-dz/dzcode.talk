### General Notes

1> Keep a basic boilerplate prepared so I can get to coding soon.

2> I suspect that the average senior JS dev would take somewhere around 4-8 hours to complete a prototype without bugs. 


## Some example exercise

1> A calendar

2>  a todo list options to add new item, edit, delete, view details, filter by date and store all changes to the server via REST API. It’s a simple example, but will put to test knowledge of handling CRUD operations, routing, storing to server.

3> Weather fetching and geolocation app.

4> 
