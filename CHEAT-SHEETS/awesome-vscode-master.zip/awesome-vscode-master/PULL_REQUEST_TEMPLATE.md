## Name of the extension you are adding

...

## Why do you think this extension is awesome?

...

## Make sure that:

<!-- 
Check off the checkboxes with an 'x' like this: [x] 
-->

- [ ] Screenshot/GIF included (to demonstrate the plugin functionality)

- [ ] ToC updated
