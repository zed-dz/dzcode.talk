'use strict';

import html from './html.json';
import css from './css.json';
import xsl from './xsl.json';

export default { html, css, xsl };
