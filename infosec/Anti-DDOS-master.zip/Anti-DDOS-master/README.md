## Anti DDOS | BASH SCRIPT

![anti-ddos](https://user-images.githubusercontent.com/15425071/34910181-caa9f41c-f8c0-11e7-9ec5-6d43adfeb4bd.png) ![bash-language](https://user-images.githubusercontent.com/15425071/34910256-37569a6a-f8c2-11e7-81d8-42dec07d4ef8.png)

### Programming Languages :

* BASH

### System :

* Linux

### Explanation :

Anti-DDOS project is an open source software project developed to protect against DOS and DDoS attacks. The project was written using bash programming language. By writing iptables rules into the Linux operating system. Takes the necessary defense configurations. And it only works on the linux operating system. 100% compatible for Linux operating systems. It does not provide 100% security, it will only help you to take the necessary measures.

### How to use ?

You need to set the config file according to your system architecture.

### RUN
```
root@ismailtasdelen:~# bash ./anti-ddos.sh
```

### Cloning an Existing Repository ( Clone with HTTPS )
```
root@ismailtasdelen:~# git clone https://github.com/ismailtasdelen/Anti-DDOS.git
```

### Cloning an Existing Repository ( Clone with SSH )
```
root@ismailtasdelen:~# git clone git@github.com:ismailtasdelen/Anti-DDOS.git
```

### About DOS and DDOS :

##### Denial of Service : https://www.owasp.org/index.php/Denial_of_Service

##### Denial of Service Cheat Sheet : https://www.owasp.org/index.php/Denial_of_Service_Cheat_Sheet

##### Application Denial of Service : https://www.owasp.org/index.php/Application_Denial_of_Service

##### Testing for Denial of Service : https://www.owasp.org/index.php/Testing_for_Denial_of_Service

##### DRAFT Denial of Service Cheat Sheet : https://www.owasp.org/index.php/DRAFT_Denial_of_Service_Cheat_Sheet

##### Regular expression Denial of Service - ReDoS : https://www.owasp.org/index.php/Regular_expression_Denial_of_Service_-_ReDoS

### Published Website :

##### KitPloit - https://www.kitploit.com/2017/10/anti-ddos-anti-ddos-bash-script.html

##### CISOfy - https://linuxsecurity.expert/tools/anti-ddos/

### Contact :

##### Mail : ismailtasdelen@protonmail.com

##### Linkedin : https://www.linkedin.com/in/ismailtasdelen

##### GitHub : https://github.com/ismailtasdelen

##### Telegram : https://t.me/ismailtasdelen
