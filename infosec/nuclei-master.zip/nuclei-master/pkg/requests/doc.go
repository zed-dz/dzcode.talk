// Package requests implements requests for templates that
// will be sent to hosts.
package requests
