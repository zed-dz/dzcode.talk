# Modern Workflow + Tooling

These are the slides to my talk - they might not make a ton of sense without the talk, but you are welcome to look at them. 

Watch it here → <http://wesbos.com/modern-javascript-workflow-tooling/>

[![](http://wesbos.com/wp-content/uploads/2015/11/ss-2015-11-17-at-10.18.05-AM.png)](http://wesbos.com/modern-javascript-workflow-tooling/)

View at [wesbos.github.io/Modern-Workflow-and-Tooling-Talk](http://wesbos.github.io/Modern-Workflow-and-Tooling-Talk). Use your `←` and `→` keys to move through the slides. 

Small screen users should zoom out - these slides are 1080p.

## The Code + Content

These slides are built with Flexbox, Gulp, Jade, Stylus and Browsersync all on top of the Google slide deck JS.

The code Licensed MIT - you can use this to make your own slide deck.

If you'd like to use the content for training or doing your own talk, please get in touch with me first. 



