package cmd

func getUmask() int {
	return 0
}
