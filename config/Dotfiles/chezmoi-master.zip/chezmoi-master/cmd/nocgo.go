// +build !cgo

package cmd

const cgoEnabled = false
