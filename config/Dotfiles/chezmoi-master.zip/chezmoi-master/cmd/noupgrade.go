// +build noupgrade windows

package cmd

type upgradeCmdConfig struct{}
