// +build cgo

package cmd

const cgoEnabled = true
