package main

import "github.com/twpayne/chezmoi/cmd"

func main() {
	cmd.Execute()
}
