fish tricks

sending stderr to devnull

    2> /dev/null
    ag "addEventListener\([^\s\),],[^\s\),]*?,{" 2> /dev/null


escaping to bash

     /bin/sh -c "(cd $argv[1] && python -m http.server)"


