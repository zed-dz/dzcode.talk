## Win 笔记


### Windows 下安装配置 neovim

是的 neovim-qt 打开后占80%屏幕

修改启动参数为：

```
"D:\Program Files\Neovim\bin\nvim-qt.exe" -qwindowgeometry 1300x650+20+20
```
