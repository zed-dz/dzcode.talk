# About Me

My name is Wang Shidong. I'm an amateur programmer.

## Follow Me

- <i class="fab fa-github"></i> [GitHub](https://github.com/wsdjeg)
- <i class="fab fa-twitter"></i> [Twitter](https://twitter.com/wsdtty)


## Contact

- <i class="fas fa-envelope"></i> Email: wsdjeg(at)outlook.com
