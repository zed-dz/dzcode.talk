# tools with vim-like keybindings

I like vim and command line, here is a list of tools with vim-like keybindings I used.

- file manager - [vifm](https://github.com/vifm/vifm)
- image viewer - [vimiv](https://github.com/karlch/vimiv)
- firefox add-ons - [Vimperator](http://vimperator.org/)

