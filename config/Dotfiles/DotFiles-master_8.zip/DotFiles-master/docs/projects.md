# 我的开源项目

<!-- vim-markdown-toc GFM -->

- [SpaceVim](#spacevim)
- [Github.vim](#githubvim)

<!-- vim-markdown-toc -->

## SpaceVim

SpaceVim 是一个模块化的 Vim IDE，以模块的方式管理各种语言相关的插件。让搭建语言开发环境更加简单方便。

![welcome-page](https://user-images.githubusercontent.com/13142418/37595020-273b5bca-2bb2-11e8-8aba-638ed5f1c7ea.png)

- 中文官网： <https://spacevim.org/cn/>
- Github： <https://github.com/SpaceVim/SpaceVim>

## Github.vim
