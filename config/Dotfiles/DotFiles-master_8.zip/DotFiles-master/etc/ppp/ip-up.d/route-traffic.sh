#!/bin/bash
/sbin/route del default
/sbin/route add default dev ppp0
