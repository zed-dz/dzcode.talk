#!/bin/bash
./scripts/backup_package_list.sh
./scripts/backup_gem_list.sh
./scripts/backup_npm_list.sh
./scripts/backup_pip2_list.sh
./scripts/backup_pip3_list.sh
