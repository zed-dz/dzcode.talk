#!/bin/sh

./configure \
    --with-features=huge \
    --with-compiledby="wsdjeg" \
    --enable-multibyte \
    --enable-gui=no \
    --enable-gpm \
    --prefix=/home/wsdjeg/.vims/74052 \
