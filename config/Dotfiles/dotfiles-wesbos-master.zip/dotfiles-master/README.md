# dotfiles

Hey wes what settings do you use?

These are my config setting for various apps, editors and linters. I'd suggest not copying them directly but referencing what I have and what ones might make sense for you.

These are constantly changing as I work on different types of projects so I don't necessarily always have an answer to "y do u do ____ instead of ____" 

Enjoy! 😘
