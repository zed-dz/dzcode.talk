const { prettierrc } = require("poetic");

module.exports = {
  ...prettierrc
  // Add custom rules here
  // printWidth: 100,
};
