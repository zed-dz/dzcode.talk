const prettierConfig = require("./prettier/.prettierrc");

module.exports = {
  prettierConfig
};
