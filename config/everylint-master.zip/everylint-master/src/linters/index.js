import html from './html';
import javascript from './javascript';
import markdown from './markdown';
import style from './style';

export default { html, javascript, markdown, style };
