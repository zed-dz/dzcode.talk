module.exports = {
  linters: {
    javascript: {
      rules: {
        semi: 2,
      },
    },
  },
};
