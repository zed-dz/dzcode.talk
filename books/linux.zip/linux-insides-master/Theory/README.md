# Theory

This chapter describes various theoretical concepts and concepts which are not directly related to practice but useful to know.

* [Paging](linux-theory-1.md)
* [Elf64 format](linux-theory-2.md)
* [Inline assembly](linux-theory-3.md)
