# Misc

This chapter contains parts which are not directly related to the Linux kernel source code and implementation of different subsystems.
