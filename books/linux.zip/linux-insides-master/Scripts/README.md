# Scripts

## Description

`get_all_links.py` : justify one link is live or dead with network connection

`latex.sh` : a script for converting Markdown files in each of the subdirectories into a unified PDF typeset in LaTeX

## Usage

`get_all_links.py` :

```
./get_all_links.py ../
```

`latex.sh` :

```
./latex.sh
```
