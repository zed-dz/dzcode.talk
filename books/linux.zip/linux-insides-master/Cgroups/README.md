# Cgroups

This chapter describes `control groups` mechanism in the Linux kernel.

* [Introduction](linux-cgroups-1.md)
