---
title: A post with images
slug: a-post-with-images
cover: ./cover.jpg
generate-card: false
date: 2018-09-29
language: en
tags:
  - gatsby
---

## How it works?
  
1. copy/paste the image in the post folder
2. `![put image description here](./git-push-force.gif)`

![a funny gif](./git-push-force.gif)

