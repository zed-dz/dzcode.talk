---
title: Bold Mage (fake post)
slug: bold-mage
date: 2017-01-01
cover: ./cover.jpg
generate-card: false
language: en
tags:
    - programming
    - stuff
    - fake
---

## Sedisti civiliter

Lorem **markdownum** Ixione palus **semper peritura barbaque** in aureus
obliquum erigitur gemmae utque cur natus, aera supplice de nudae. Manus
ambrosiam tendens, saecula tenet, conponere et ense et cucurri. Tantique
animalia praeceps Meleagre greges venisse corpore et ignara, umquam ipse? Quam
*Talibus ausis*.

## Vultusque subsequitur Pallas regis datis inde animaque

At securim cautum capitis, creatos sanguinis turbant iam concita videor, edere.
Alis genas rudis felix quas **longum** suorum manu ante prima **usque**. Nec pro
mea pariter, ictus iam consequitur capillos elegit ego; quoniam **fuit**. Aether
Peleus Aeneadae audacia cruentatis turbae Procrin dirum bacae, accede.

```rust
fn main() {
    let strings = vec!["tofu", "93", "18"];
    let numbers: Vec<_> = strings
        .into_iter()
        .map(|s| s.parse::<i32>())
        .filter_map(Result::ok)
        .collect();
    println!("Results: {:?}", numbers);
}
```

## Fortis dextrae humo limina Tempus singultibus illa

Nate muros orbe [patris](http://debebuntilla.org/res-ego) rigent, nec tumida,
pigra iuste At spretarumque latus et nostrum. Passa videtur: inde aut de
sociorum: pars est, qualesque spes factum terris. Custodia sum animumque; iubet
in pulvere carus, relinquunt incitat. Aliis quo tribus, vertice cesserunt
vulneribus nostrae mollire erant ferrum habet loquiturque precibus expersque
quam etiamnunc. Puraque [repetitque](http://mihi-aiax.io/suaferunt.aspx),
funestaque crebros mihi conubia matres insopitumque residunt rogat ponto canos
ergo firmat albentia verba casuque.

```jsx
const Hero = props => {
  const { siteCover } = useSiteMetadata()
  const { fluid } = useSiteImages(siteCover)
  const heroImg = props.heroImg || fluid.src

  return (
    <HeroContainer style={{ backgroundImage: `url("${heroImg}")` }}>
      <TitleContainer>
        <HeroTitle>{props.title}</HeroTitle>
        {props.subTitle && <HeroSubTitle>{props.subTitle}</HeroSubTitle>}
      </TitleContainer>
    </HeroContainer>
  )
}

export default Hero
```

## Nati expugnacior nympha milia nascuntur amico

Multis timidus hic si auctor hausit. Suos taedasque, malis est nitente sceleri
sunt florem.

Sub quid deprenderat mores postquam tectoque maiestatemque debebat quibus;
subitam amittere illius esse dona. Quamvis patris virtutem, partem una per
iuvenaliter, stupet, sed nullae sepulto moderato? Nec phaedimus aequoris dixit.
Hic bis parenti: e petunt satis.