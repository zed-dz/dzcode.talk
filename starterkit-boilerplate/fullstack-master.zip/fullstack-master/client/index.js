// app entry
import App from './src'
export default App
