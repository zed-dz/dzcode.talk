/// <reference types="react-scripts" />
declare module 'react-load-script'
