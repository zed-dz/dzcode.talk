#!/usr/bin/env node

/*
 * This file is part of the express-artisan package.
 *
 * (c) Yasser Ameur El Idrissi <getspookydev@gmail.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

'use strict';

require('./expressArtisan');
