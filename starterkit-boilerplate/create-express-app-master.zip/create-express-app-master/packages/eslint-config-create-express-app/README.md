# eslint-config-create-express-app

This package includes the global ESLint configuration used by Create Express App.<br>
Please refer to its documentation:

- [Getting Started]() How to create a new app.
- [Contributing]() We are still working on refining it and contributions are welcome!

# Why Lint?

Coding always leaves room for errors, especially with loosely typed languages like JavaScript. By implementing a linter in our code editor and our project, we can save time by finding an error before we even execute our code
