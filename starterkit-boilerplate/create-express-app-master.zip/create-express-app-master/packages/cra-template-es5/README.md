# cra-template-es5

This is the official es5 template for [create-express-app](https://github.com/getspooky/create-express-app). <br>

For more information, please refer to:

- [Getting Started](https://github.com/getspooky/create-express-app#Getting-Started) How to create a new app.
- [Contributing](https://github.com/getspooky/create-express-app/blob/master/CONTRIBUTING.md) We are still working on refining it and contributions are welcome!
