# create-express-app

This package includes the global command for Create Express App.<br>
Please refer to its documentation:

- [Getting Started](https://github.com/getspooky/create-express-app#Getting-Started) How to create a new app.
- [Contributing](https://github.com/getspooky/create-express-app/blob/master/CONTRIBUTING.md) We are still working on refining it and contributions are welcome!
