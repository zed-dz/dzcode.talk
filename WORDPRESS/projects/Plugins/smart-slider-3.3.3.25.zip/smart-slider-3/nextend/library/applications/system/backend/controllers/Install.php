<?php


class N2SystemBackendInstallController extends N2BackendController {

    public function initialize() {
    }

    public function actionIndex($secured = false) {
    }
}
