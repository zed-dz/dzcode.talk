<?php
/**
 * WPSEO plugin file.
 *
 * @package WPSEO\CLI
 */

use WP_CLI\Dispatcher\CommandNamespace;

/**
 * The redirect functionality is only available in Yoast SEO Premium.
 */
final class WPSEO_CLI_Redirect_Upsell_Command_Namespace extends CommandNamespace {
	// Intentionally left empty.
}
