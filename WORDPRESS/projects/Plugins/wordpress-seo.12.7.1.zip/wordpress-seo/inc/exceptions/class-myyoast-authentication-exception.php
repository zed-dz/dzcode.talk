<?php
/**
 * WPSEO plugin file.
 *
 * @package WPSEO\Internals
 */

/**
 * Class WPSEO_MyYoast_Authentication_Exception.
 */
class WPSEO_MyYoast_Authentication_Exception extends WPSEO_MyYoast_Bad_Request_Exception {

}
