<?php

define( 'REDIRECTION_VERSION', '4.5.1' );
define( 'REDIRECTION_BUILD', '77207e69fee0b331324f0be84e962d5c' );
define( 'REDIRECTION_MIN_WP', '4.6' );
