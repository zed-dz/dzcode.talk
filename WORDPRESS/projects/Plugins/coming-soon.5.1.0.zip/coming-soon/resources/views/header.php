<div id="seed_csp4_header">
<h1>
	<img style="width:140px;margin-right:10px;vertical-align: sub;" src="<?php echo SEED_CSP4_PLUGIN_URL ?>public/images/seedprod-logo-white.png"> 
	 Coming Soon Page and Maintenance Mode Lite
	<span class="seed_csp4_version" style="font-size: 10px;"> Version <?php echo SEED_CSP4_VERSION; ?></span>
</h1>
<span id="seed_csp4_header_bg" class="dashicons dashicons-chart-area"></span>

</div>

