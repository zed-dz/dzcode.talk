<?php
/**
 * Author: ExactMetrics team
 * Copyright 2018 ExactMetrics team
 * Author URI: https://exactmetrics.com
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 */
?>
<amp-analytics type="googleanalytics" id="gadwp-googleanalytics">
	<script type="application/json">
<?php echo $data['json']; ?>
	</script>
</amp-analytics>
