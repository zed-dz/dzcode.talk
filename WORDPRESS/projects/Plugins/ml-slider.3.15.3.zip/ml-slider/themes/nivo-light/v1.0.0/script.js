window.jQuery(function ($) {
	/**
	 * Extra JS for the Nivo Light theme
	 */

	$('.ms-theme-nivo-light .slider-wrapper').each(function () {
		$(this).removeClass('theme-default');
	});
});