<?php
//Nothing to see here

header( 'HTTP/1.0 403 Forbidden' );