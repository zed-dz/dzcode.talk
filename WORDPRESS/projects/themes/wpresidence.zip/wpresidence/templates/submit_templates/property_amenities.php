<?php
global $edit_id;
global $moving_array;
global $wpestate_submission_page_fields;

$list_to_show='';
$terms              =   get_terms( array(
                                'taxonomy' => 'property_features',
                                'hide_empty' => false,
                            ));
    

 foreach($terms as $checker => $term){
    
    if(  is_array($wpestate_submission_page_fields) && in_array($term->slug, $wpestate_submission_page_fields)  ) { 

        $feature_name   =   $term->slug;
        $feature_name   =   str_replace('%','', $feature_name);
        
        $list_to_show.= '<p class="featurescol">
               <input type="hidden"    name="'.esc_attr($feature_name).'" value="" >
               <input type="checkbox"   id="'.esc_attr($feature_name).'" name="'.esc_attr($feature_name).'" value="1" ';

        if( has_term( $term->name, 'property_features',$edit_id ) || ( isset($_POST[$feature_name]) && $_POST[$feature_name]==1 )  ) {
            $list_to_show.=' checked="checked" ';
        }else{
            if(is_array($moving_array) ){                      
                if( in_array(sanitize_title($term->name),$moving_array) ){
                    $list_to_show.= ' checked="checked" ';
                }
            }
        }
        $list_to_show.= ' /><label for="'.esc_attr($feature_name).'">'.$term->name.'</label></p>';  
    }
}
?>



    <div class="col-md-12 add-estate profile-page profile-onprofile row"> 
        <div class="submit_container ">  
            <div class="col-md-4 profile_label">
                <div class="user_details_row"><?php esc_html_e('Amenities and Features','wpresidence');?></div> 
                <div class="user_profile_explain"><?php esc_html_e('Select what features and amenities apply for your property. ','wpresidence')?></div>
            </div>

            <div class="col-md-8">
                <?php print trim($list_to_show);?>
            </div>

        </div>
    </div>

