window.onload = function() {

/* add list view to only the home page */
let listing = document.querySelectorAll(".home #listing_ajax_container .listing_wrapper ");
for (i = 0; i < listing.length; i++) {
listing[i].classList.remove("col-md-12");
listing[i].classList.add("col-md-4");
}

/* add subject to form */
// select the form div container
if(document.querySelector("#agent_phone")) {
 let form = document.querySelector("#agent_phone");
 form.insertAdjacentHTML("afterend", "<input name='contact_subject' type='text' placeholder='Subject' aria-required='true' id='agent_contact_subject' class='form-control' />");
}

function fbpopup(event) {
  event.preventDefault();
  const facebookWindow = window.open(`https://web.facebook.com/sharer/sharer.php?u=${document.URL}`);
  if (facebookWindow.focus) { facebookWindow.focus();  }
  return false;
}

if(document.querySelector(".property_reviews_wrapper")) {
 let review = document.querySelector(".property_reviews_wrapper");
 review.insertAdjacentHTML("afterend", "<p><a href='#' class='share_social'>Share with <span class='fa fa-facebook' data-js='facebook-share'></span></a></p>");
 
 if(document.querySelector('[data-js="facebook-share"]') || (document.querySelector('.share_social'))) {
     const facebookShareP = document.querySelector('.share_social');
     const facebookShareAtt = document.querySelector('[data-js="facebook-share"]');
     facebookShareP.addEventListener('click', fbpopup);
     facebookShareAtt.addEventListener('click', fbpopup);
 }
}



}