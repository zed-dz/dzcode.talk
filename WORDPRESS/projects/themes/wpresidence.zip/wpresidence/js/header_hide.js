let prevScrollpos = window.pageYOffset;
window.onscroll = function() {

  let currentScrollPos = window.pageYOffset;
  if (prevScrollpos <= currentScrollPos) {
       document.querySelector(".master_header").style.display = "none";
 } else {
       document.querySelector(".master_header").style.display = "";
  }
  prevScrollpos = currentScrollPos;
}
