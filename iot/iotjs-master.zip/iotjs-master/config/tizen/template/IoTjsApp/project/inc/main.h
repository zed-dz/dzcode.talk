#ifndef __$(appName)_H__
#define __$(appName)_H__

#include <dlog.h>

#ifdef  LOG_TAG
#undef  LOG_TAG
#endif
#define LOG_TAG "$(appName)"


#endif /* __$(appName)_H__ */
