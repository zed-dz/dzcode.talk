console.log('Hello IoT.js');

