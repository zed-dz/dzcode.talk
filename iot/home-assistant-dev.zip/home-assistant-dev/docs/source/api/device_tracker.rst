.. _components_device_tracker_module:

:mod:`homeassistant.components.device_tracker`
----------------------------------------------

.. automodule:: homeassistant.components.device_tracker
    :members:

.. autoclass:: Device
    :members:
