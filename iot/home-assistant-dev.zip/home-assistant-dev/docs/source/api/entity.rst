.. _helpers_entity_module:

:mod:`homeassistant.helpers.entity`
-----------------------------------

.. automodule:: homeassistant.helpers.entity

.. autoclass:: Entity
    :members:

.. autoclass:: ToggleEntity
    :members:
