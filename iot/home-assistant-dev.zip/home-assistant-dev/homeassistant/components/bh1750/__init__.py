"""The bh1750 component."""
