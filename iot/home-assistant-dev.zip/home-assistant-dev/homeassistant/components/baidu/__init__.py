"""Support for Baidu integration."""
