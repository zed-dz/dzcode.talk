"""The avion component."""
