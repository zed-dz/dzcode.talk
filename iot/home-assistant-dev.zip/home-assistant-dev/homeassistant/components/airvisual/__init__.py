"""The airvisual component."""
