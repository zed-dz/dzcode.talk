"""The bitcoin component."""
