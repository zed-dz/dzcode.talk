"""The alpha_vantage component."""
