"""The awair component."""
