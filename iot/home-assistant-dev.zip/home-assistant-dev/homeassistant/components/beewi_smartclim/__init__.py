"""The beewi_smartclim component."""
