"""Support for functionality to interact with Android TV/Fire TV devices."""
