"""The apns component."""
