"""The bbox component."""
