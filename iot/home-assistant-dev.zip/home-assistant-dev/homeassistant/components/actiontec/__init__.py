"""The actiontec component."""
