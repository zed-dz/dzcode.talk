"""The bayesian component."""
