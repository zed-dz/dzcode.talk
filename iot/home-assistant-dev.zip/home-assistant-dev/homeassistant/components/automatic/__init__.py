"""The automatic component."""
