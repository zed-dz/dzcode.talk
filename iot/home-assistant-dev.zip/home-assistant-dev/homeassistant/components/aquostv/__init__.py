"""The aquostv component."""
