module.exports = {
	panda: true,
	bear: true,
	authToken: '',
	serverUri: '',
};
