# Contributing to RealWorld

### Interested in creating Conduit for your framework?

To create an official implementation of Conduit, check out our Github issues and see if anyone else has requested and/or is already working on your framework. If not, feel free to open an issue and start working on one!

Also, we're more than happy to link to unofficial Conduit creations/forks in our README. Simply make a pull request!
