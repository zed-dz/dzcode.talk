### Startup Programs and Schools

> **Add in Proper Section after research**

1. Build.org
2. Young Entrepreneurs Academy
3. Future Founders
4. Global Engagement Summit ( Illinios )
5. Whatever it takes
6. 1517 Fund
7. We are Family Foundation
8. SEED SPOT
9. One Young Summit
10. Miami Dade College (Florida)
11. African Leadership Academy
12. ASU Changemaker Central (Arizona)
13. United World College
14. CU Boulder (Entrepreneurship Programs)
15. Youth Initiative High School (Wisconsin)
16. Think Global Schools
17. School of Entrepreneurship and Technology (California)
18. The Future Project
19. Global Citizen Year
20. Ashoka Youth Venture
21. Thread
