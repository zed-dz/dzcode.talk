

# A to Z Resources for Students ![Awesome](https://cdn.rawgit.com/sindresorhus/awesome/d7305f38d29fed78fa85652e3a63e154dd8e8829/media/badge.svg)


![Image](res/gsoc.jpg)

# Google Summer of Code 

## 1. List of Top Orgranisation in GSOC
### a. Mozilla

### b. The Apache Software Foundation (Java, C, Erlang)

### c. Django Software Foundation(Python, Django)

### d. FossAsia(Java, Javascript)

### e. Git (C, Shellscript)

### f. Gnome (C, Python, Javascript)

### g. Institute for Artificial Intelligence (C++, Python)

### h. Metasploit (Ruby, Python ,C)

### i. Teammates (Java, Google Cloud Engine)
# COMING SOON

- TODO
