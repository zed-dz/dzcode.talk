---
title: Testing Questions
layout: layouts/page.njk
permalink: /questions/testing-questions/index.html
---

* What are some advantages/disadvantages to testing your code?
* What tools would you use to test your code's functionality?
* What is the difference between a unit test and a functional/integration test?
* What is the purpose of a code style linting tool?
