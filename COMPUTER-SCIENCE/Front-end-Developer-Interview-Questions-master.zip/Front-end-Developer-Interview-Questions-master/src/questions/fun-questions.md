---
title: Fun Questions
layout: layouts/page.njk
permalink: /questions/fun-questions/index.html
---

* What's a cool project that you've recently worked on?
* What are some things you like about the developer tools you use?
* Who inspires you in the front-end community?
* Do you have any pet projects? What kind?
* What's your favorite feature of Internet Explorer?
* How do you like your coffee?
