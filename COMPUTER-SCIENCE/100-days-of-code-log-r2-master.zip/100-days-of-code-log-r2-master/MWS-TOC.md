---
title: MWS Phase 1 Notes
description: Grow with Google Scholarship Challenge - Mobile Web Specialist track
---
<!-- markdownlint-disable MD022 MD024 MD032 -->
# Mobile Web Specialist - Phase 1 Notes
This is my complete list of notes taken from Phase 1 of **Grow With Google Scholarship Challenge - Mobile Web Specialist** track.

This was the 3 month precursor to the Google/Udacity **Mobile Web Specialist Nanodegree** program.

## Notes Table of Contents

1. Course Notes - [Offline First (1) - Introducing the Service Worker](Introducing-the-Service-Worker.html)
2. Course Notes - [Offline First (2) - IndexedDB and Caching](IndexedDB-and-Caching.html)
3. Course Notes - [ES6 JavaScript Improved (1) - Syntax](ES6-Syntax.html)
4. Course Notes - [ES6 JavaScript Improved (2) - Functions](ES6-Functions.html)
5. Course Notes - [ES6 JavaScript Improved (2.5) - Classes](ES6-Classes.html)
6. Course Notes - [ES6 JavaScript Improved (3) - Built-ins](ES6-Built-ins.html)
7. Course Notes - [ES6 JavaScript Improved (3.5) - Built-ins-Pt2](ES6-Built-ins-Pt2.html)
8. Course Notes - [ES6 JavaScript Improved (4) - Professional Developer-fu](ES6-Professional-Developer-fu.html)