Welcome!

For contributions to be approved they should respect this form :

`* [Site name | A simple description](url) : a simple description of the site or slogan of the site. `

__NEW :You should also consider sorting your submission alphabetically.__

And adhere to the [Contributor Covenant Code of Conduct](./CODE_OF_CONDUCT.md)
