## Four Semesters of Computer Science in 5 Hours

Welcome to the code behind the [course website](http://btholt.github.io/four-semesters-of-cs/) for the [Four Semesters of Computer Science in 5 Hours](https://frontendmasters.com/courses/computer-science/) course on Frontend Masters.
