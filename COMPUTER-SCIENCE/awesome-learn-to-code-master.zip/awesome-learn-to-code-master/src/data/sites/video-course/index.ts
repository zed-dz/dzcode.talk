import fem from './frontend-masters';

export default [...fem];
