import next from './tutorials/next';
import solo from './tutorials/solo-learn';

export default [next, solo];
