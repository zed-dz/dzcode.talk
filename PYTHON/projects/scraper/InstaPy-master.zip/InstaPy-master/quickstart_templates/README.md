## How to use the templates?

It's really easy, all you have to do is copy the template you like into the "root" folder of InstaPy. 

> The same folder the actual quickstart.py is in

Edit the file and fill in your username and password.
If wanted also adjust the used tags, account names and ignore lists to fit your needs.

WARNING; some of the follow/liking limits may not be best to use with Instagram's ever changing limits. Start small and play around with these.
