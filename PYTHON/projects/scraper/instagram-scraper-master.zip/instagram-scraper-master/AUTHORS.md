Authors
=======

instagram-scraper is written and maintained by Richard Arcega, along with the following contributors:

- Charlie Gorichanaz ([@CNG](https://github.com/CNG))
- Jacob Lukose ([@jacoblukose](https://github.com/jacoblukose))
- Nace Oroz ([@orkaa](https://github.com/orkaa))
- Leif Sawyer ([@akhepcat](https://github.com/akhepcat))
- Dave Bush ([@corymb](https://github.com/corymb))
- Dillon Newell ([@DillonN](https://github.com/DillonN))
- Daniel M. Capella ([@polyzen](https://github.com/polyzen))
- Carl Helmertz ([@chelmertz](https://github.com/chelmertz))
- Gaurav Kalra ([@gvkalra](https://github.com/gvkalra))
- Yunru Liu ([@YunruLiu](https://github.com/YunruLiu))
- Christopher Cintron ([@ChrisCintron](https://github.com/ChrisCintron))
- Steve Schmidt ([@stvschmdt](https://github.com/stvschmdt))
- John Pimental ([@Emalton](https://github.com/Emalton))
- kcayut ([@kcayut](https://github.com/kcayut))
