import React from 'react';
import Config from 'config/constants';
import Image from 'components/image/Image';

/**
 * @TODO: Add Patreon Button
 */
function DonateButton() {
  return (
    <div/>
  );
}

export default DonateButton;
