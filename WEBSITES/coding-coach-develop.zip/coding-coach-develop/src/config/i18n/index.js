import en from './en/messages.js';
import es from './es/messages.js';
import fr from './fr/messages.js';

export const catalogs = { en, es, fr };
