export { default as Home } from './home/Home';
export { default as Login } from './auth/Login';
export { default as ForgotPassword } from './auth/ForgotPassword';
export { default as PrivateViews } from './auth/PrivateViews';
export { default as Dashboard } from './dashboard/Dashboard';
export { default as Opening } from './openings/Opening';
