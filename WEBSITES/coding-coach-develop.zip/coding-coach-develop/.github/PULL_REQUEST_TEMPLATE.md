# Details

## Description

<!-- ADD A DETAILED DESCRIPTION OF THE PULL REQUEST AND WHAT IT INTENDS TO SOLVE. -->

## Steps to QA

<!-- IF UNNECESSARY, REMOVE THIS SECTION. OTHERWISE, LIST STEPS SOMEONE CAN TAKE TO QA THE FEATURE OR BUG. -->

- [ ] Step 1

## Screenshots

<!-- IF UNNECESSARY, REMOVE THIS SECTION. OTHERWISE, PROVIDE SCREENSHOTS OF YOUR CHANGE IF IT PERTAINS TO THE UI. -->

## Issue

<!-- IF UNNECESSARY, REMOVE THIS SECTION. OTHERWISE, REFERENCE THE GITHUB ISSUE, OR ISSUES, THIS PR PERTAINS TO. -->


<!-- Closing just one issue use this -->
<!-- For example, to close an issue numbered 123, you could use the phrase "Closes #123" -->
Closes #123

<!-- Or, Closing multiple issues -->
<!-- To close multiple issues, preface each issue reference with "closes" keywords -->
<!-- For example, `This closes #34, closes #23, and closes #42` would close issues #34, #23 and #42 -->
This closes #34, closes #23, and closes #42
