---
templateKey: footer
logoImage:
  image: /img/js-wakanda.png
  imageAlt: JavaScript Wakanda
  tagline: Your friendly local Wakanda meetup
socialLinks:
  - image: /img/meetup.svg
    imageAlt: Join us on meetup.com
    label: meetup.com
    linkURL: 'https://www.meetup.com/'
  - image: /img/twitter.svg
    imageAlt: Follow us on Twitter
    label: twitter.com
    linkURL: 'https://twitter.com/'
  - image: /img/facebook.svg
    imageAlt: Join our Facebook group
    label: facebook.com
    linkURL: 'https://www.facebook.com/'
  - image: /img/email.svg
    imageAlt: Contact us by email
    label: email us
    linkURL: 'mailto:contact@js-wakanda.org'
---

