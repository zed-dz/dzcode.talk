---
templateKey: past-meetups-page
title: Past Meetups
path: /meetups
seo:
  browserTitle: Past Meetups | JS Wakanda
  description: View the topics that were presented at past JavaScript Montreal meetups.
  title: Past Meetups | JavaScript Wakanda
---

Here are some of the subjects we've covered in past meetups. If you're interested in participating by giving a talk, don't worry too much if we've touched on the subject before. New people join every day and there are a lot of subjects warranting a re-visit.
