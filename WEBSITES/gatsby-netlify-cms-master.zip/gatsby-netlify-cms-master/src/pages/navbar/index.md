---
templateKey: navbar
menuItems:
  - label: home
    linkType: internal
    linkURL: /
  - label: about
    linkType: internal
    linkURL: /about
  - label: past meetups
    linkType: internal
    linkURL: /meetups
---

