---
title: November 2060
date: 2060-11-09T23:00:00.000Z
presenters:
  - image: /img/jonas-kakaroto-577554-unsplash.jpg
    links:
      - linkText: Github Example
        linkURL: 'https://github.com/'
      - linkText: Conference Talk Recording
        linkURL: 'https://github.com/'
    name: Wes Tanner
    presentationTitle: Advanced React
    text: >-
      Wes is going to guide use on how to build a full stack react and graphql
      app using Appolo, GraphQL Yoga, and Prisma.
  - image: /img/benjamin-parker-736167-unsplash.jpg
    links:
      - linkText: Twitter
        linkURL: 'https://twitter.com/'
    name: Scott Brolinski
    presentationTitle: Meteor.js Framework
    text: >-
      Scott will take use through the Meteor JavaScript framework and how it’s
      awesome in every way.
location:
  mapsLatitude: 64.843779
  mapsLink: 'https://goo.gl/maps/Rm6ihxVrZGK2'
  mapsLongitude: -147.718189
  name: Fairbanks Ice Museum
---

