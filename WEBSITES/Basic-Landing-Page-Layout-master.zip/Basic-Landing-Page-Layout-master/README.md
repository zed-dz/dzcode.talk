# Basic-Landing-Page-Layout
A basic landing page layout template using mainly CSS (Grid and Flex).
