import { globalStyles } from "@styles/global";
import { media } from "@styles/media";

export { globalStyles, media };
