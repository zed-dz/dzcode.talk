export { default } from '@components/SEO/SEO'
