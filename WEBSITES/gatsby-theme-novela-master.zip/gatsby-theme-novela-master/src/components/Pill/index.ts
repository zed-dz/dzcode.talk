export { default } from './Pill'
