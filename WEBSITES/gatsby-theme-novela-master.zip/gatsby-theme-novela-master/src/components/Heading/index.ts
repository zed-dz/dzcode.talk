export { default } from "./Heading";
