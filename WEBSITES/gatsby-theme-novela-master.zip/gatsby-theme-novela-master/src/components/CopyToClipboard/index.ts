export { default } from '@components/CopyToClipboard/CopyToClipboard'
