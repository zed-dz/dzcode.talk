import CSSFadeIn from "@components/Transitions/Transitions.CSS.FadeIn";

export default {
  CSS: {
    FadeIn: CSSFadeIn,
  },
};
