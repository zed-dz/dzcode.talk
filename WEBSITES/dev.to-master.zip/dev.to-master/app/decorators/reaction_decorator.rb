class ReactionDecorator < ApplicationDecorator; end
