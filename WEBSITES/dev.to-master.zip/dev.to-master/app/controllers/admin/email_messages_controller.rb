module Admin
  class EmailMessagesController < Admin::ApplicationController
    # To customize the behavior of this controller,
    # simply overwrite any of the RESTful actions. For example:
    #
    # def index
    #   super
    #   @resources = Ahoy::Message.
    #     page(params[:page]).
    #     per(8)
    # end

    # Define a custom finder by overriding the `find_resource` method:
    # def find_resource(param)
    #   Ahoy::Message.find_by!(slug: param)
    # end

    # See https://administrate-prototype.herokuapp.com/customizing_controller_actions
    # for more information
  end
end
