class ProAccountsController < ApplicationController
  def index; end
end
