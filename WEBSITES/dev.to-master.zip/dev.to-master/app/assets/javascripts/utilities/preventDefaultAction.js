function preventDefaultAction(event){
  event.preventDefault();
}