import { h } from 'preact';

const UnopenedChannelNotice = () => {
  return <div style={{ position: 'absolute' }} />;
};

export default UnopenedChannelNotice;
