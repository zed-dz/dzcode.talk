import userPropTypes from './user-prop-types';
import defaultChildrenPropTypes from './default-children-prop-types';

export { userPropTypes, defaultChildrenPropTypes };
