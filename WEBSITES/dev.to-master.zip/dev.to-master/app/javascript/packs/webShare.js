/* eslint no-unused-vars: ["error", { "argsIgnorePattern": "_" }] */
import 'web-share-wrapper';
