class UnauthorizedError < StandardError; end
