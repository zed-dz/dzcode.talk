# MyTunes Landing Page

> Landing page modeled after iTunes page. This was used in a YouTube tutorial

To create mockups, use [Smartmockups](https://a.paddle.com/v2/click/19214/34221?link=783)

The responsive menu is by Ash Neilson: [Visit The Codepen](https://codepen.io/neilso/pen/ziwgI)

[View The Project](https://bradtraversy.github.io/mytunes_landing)
