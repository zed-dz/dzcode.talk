# safety-on-internet
les slides de la présentation de GDG Tizi Ouzou à la conférence organisée
par le club scientifique du département d’électronique de UMMTO à Bastos.
 
