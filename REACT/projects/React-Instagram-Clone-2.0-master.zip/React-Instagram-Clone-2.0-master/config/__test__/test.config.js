// IF any of the ID below is not present in the database, then replace it with a valid ID.

module.exports = {
  user1: 24, // ID of takkar
  user2: 7, // ID of ghalib
  postID: 89, // postId of a post (by takkar),
  conId: 24, // conversation ID,
  grpID: 11, // Group ID
  testMailTo: 'anymail@gmail.com',
}
