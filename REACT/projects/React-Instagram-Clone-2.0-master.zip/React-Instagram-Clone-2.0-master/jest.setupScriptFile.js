// import jest-extended
import 'jest-extended'

// set timeout (jest default=5000ms)
jest.setTimeout(30000)
