export default [
  {
    follow_to: 7,
    follow_to_username: 'ghalib',
  },
  {
    follow_to: 8,
    follow_to_username: 'coldplay',
  },
  {
    follow_to: 16,
    follow_to_username: 'zayn',
  },
  {
    follow_to: 19,
    follow_to_username: 'jonsnow',
  },
]
