export default [
  '/images/stickers/wall.png',
  '/images/stickers/oracles.png',
  '/images/stickers/like9.png',
]
