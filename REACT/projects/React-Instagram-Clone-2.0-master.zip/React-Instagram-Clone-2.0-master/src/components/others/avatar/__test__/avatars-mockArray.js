export default [
  '/images/avatars/wheel.jpg',
  '/images/avatars/Ronaldo-portrait-vectorport.jpg',
  '/images/avatars/saree.jpg',
  '/images/avatars/shinchan22.jpg',
]
