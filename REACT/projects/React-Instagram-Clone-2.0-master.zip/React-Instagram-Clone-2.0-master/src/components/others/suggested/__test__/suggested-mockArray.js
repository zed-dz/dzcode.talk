export default [
  {
    id: 7,
    username: 'ghalib',
    firstname: 'Mirza',
    surname: 'Ghalib',
    mutualUsersCount: 1,
  },
  {
    id: 8,
    username: 'coldplay',
    firstname: 'cold',
    surname: 'play',
    mutualUsersCount: 0,
  },
]
