import React from 'react'
import AppLink from '../../../others/link/link'

const NotificationTypeCon = () => (
  <AppLink url="/messages" className="pri_btn" label="View conversation" />
)

export default NotificationTypeCon
