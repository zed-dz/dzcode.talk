import React, { useRef, useState, useEffect, useCallback } from "react";
import ReactDOM from "react-dom";

const toggle = value => !value;

export function App() {
  const countRef = useRef(0);
  countRef.current = countRef.current + 1;

  const [isBatchEnabled, setIsBatchEnabled] = useState(false);
  const [, setState] = useState();

  const callSetStateMultipleTimes = useCallback(() => {
    function fn() {
      setState(toggle);
      setState(toggle);
      setState(toggle);
      setState(toggle);
      setState(toggle);
    }

    isBatchEnabled ? ReactDOM.unstable_batchedUpdates(fn) : fn();
  }, [isBatchEnabled]);

  useEffect(() => {
    const timer = setInterval(callSetStateMultipleTimes, 500);

    return () => {
      clearInterval(timer);
    };
  }, [callSetStateMultipleTimes]);

  return (
    <div className="App">
      <h1>Number of re-renders:</h1>
      <h2>{countRef.current}</h2>

      <label>
        <input
          type="checkbox"
          checked={isBatchEnabled}
          onChange={e => setIsBatchEnabled(e.target.checked)}
        />
        &nbsp; Use ReactDOM.unstable_batchedUpdates
      </label>
    </div>
  );
}
