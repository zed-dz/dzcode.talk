// Booking actions
export const GET_USER = 'GET_USER';
export const DUMMY_1 = 'TEST_DELETE_THIS_LATER_1';
export const DUMMY_2 = 'TEST_DELETE_THIS_LATER_2';
