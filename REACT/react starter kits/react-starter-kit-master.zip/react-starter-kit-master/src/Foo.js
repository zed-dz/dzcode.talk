import React from 'react';

export default () => (
  <div>
    <p>I am Foo! Pleasure to meet you. </p>
  </div>
);
