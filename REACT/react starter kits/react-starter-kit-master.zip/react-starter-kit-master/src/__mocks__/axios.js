export default {
  isCancel: jest.fn(),
  CancelToken: { source: jest.fn() },
};
