import React from 'react';

export default () => <p>user page</p>;
