## CCA 3.0 License

> Copyright (c) 2019 - present AppSeed

This app is licensed under the **Creative Commons Attribution 3.0 License**, which means:

- Use them for personal stuff
- Use them for commercial stuff
- Change them however you like
- Preserve the footer credit ©AppSeed

---
Made with ♥ by [AppSeed.us](https://appseed.us)
