---
path: "/intro"
title: "Introduction"
order: 0
---

This is page one.

## Check out this image

![Gatsby Logo](./images/logo.svg)

## Check out a code sample

```js
const x = 2 + 2;
```
