---
path: "/page-2"
title: "Page 2"
order: 1
---

This is page two.
