import GoogleFont from "./GoogleFont"
import TypographyStyle from "./TypographyStyle"

module.exports = {
  GoogleFont,
  TypographyStyle,
}
