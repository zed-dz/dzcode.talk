// @flow

import designTools from '../packages/typography-design-tools/src/index'

it('should return a structure', () => {
  expect(designTools).toEqual(jasmine.any(Object))
})
