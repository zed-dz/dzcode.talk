// @flow

import * as constants from '../packages/typography-breakpoint-constants/src/index'

it('should return a structure', () => {
  expect(constants).toEqual(jasmine.any(Object))
})
