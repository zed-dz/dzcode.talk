import Editor from './Editor'
export default Editor
