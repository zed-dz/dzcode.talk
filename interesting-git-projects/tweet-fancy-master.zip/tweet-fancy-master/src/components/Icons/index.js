import GitHubIcon from './GitHubIcon'

export { GitHubIcon }
