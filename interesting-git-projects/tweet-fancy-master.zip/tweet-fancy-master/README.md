# [`tweetfancy.io`](http://tweetfancy.io)

Ever fancied tweeting with **bold**, _italics_ or ~~strikethrough~~ text?

Twitter may not support it but you **can**.

Write in markdown and grab your fancy text.

🚀 [https://tweetfancy.io](https://tweetfancy.io)

###### _Note: The generated bold, italics and strikethrough texts are [UTF Mathematical Alphanumeric Symbols](https://en.wikipedia.org/wiki/Mathematical_Alphanumeric_Symbols). So if you run them by a screen reader, you'll find that the reader reads them out by their symbol name. But then, all screen readers struggle reading smileys too (🎉🔥🚀🦄😎) and that doesn't stop us from using smileys. So,we might use this as well._

## License

Copyright (c) 2019 Dineshkumar Pandiyan
