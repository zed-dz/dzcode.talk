export const environment = {
  production: true,
  API: 'https://tmxnx.com/moddoc'
};
