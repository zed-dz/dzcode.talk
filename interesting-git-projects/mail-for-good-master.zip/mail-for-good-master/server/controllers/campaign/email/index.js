const amazonController = require('./amazon-ses');

module.exports = {
  amazon: {
    controller: amazonController,
  }
};
