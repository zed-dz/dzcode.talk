<!-- Thanks for submitting an issue! All bug reports and problem issues require a **reduced test case** or **live URL**. Create one by forking any one of the CodePen examples from the docs. See guidelines link above. -->

**Test case:** http://codepen.io/desandro/pen/WOjqNM
