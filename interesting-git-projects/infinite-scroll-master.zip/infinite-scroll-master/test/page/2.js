window.page2ExternalScriptLoaded = true;
