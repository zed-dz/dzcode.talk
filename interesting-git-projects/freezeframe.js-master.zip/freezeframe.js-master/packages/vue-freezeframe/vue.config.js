module.exports = {
  publicPath: '/freezeframe.js/',
};
