import { SubmitPage } from '../src/pages/submit';

export default SubmitPage;
