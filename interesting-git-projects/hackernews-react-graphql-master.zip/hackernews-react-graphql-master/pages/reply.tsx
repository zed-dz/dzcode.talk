import { ReplyToCommentPage } from '../src/pages/reply';

export default ReplyToCommentPage;
