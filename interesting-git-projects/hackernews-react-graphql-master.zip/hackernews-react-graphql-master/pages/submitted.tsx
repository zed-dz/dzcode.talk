import { SubmittedPage } from '../src/pages/submitted';

export default SubmittedPage;
