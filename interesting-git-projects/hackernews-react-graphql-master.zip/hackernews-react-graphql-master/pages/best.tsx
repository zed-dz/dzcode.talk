import { BestPage } from '../src/pages/best';

export default BestPage;
