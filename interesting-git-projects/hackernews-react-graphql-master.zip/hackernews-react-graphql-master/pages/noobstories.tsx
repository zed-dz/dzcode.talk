import { NoobStoriesPage } from '../src/pages/noobstories';

export default NoobStoriesPage;
