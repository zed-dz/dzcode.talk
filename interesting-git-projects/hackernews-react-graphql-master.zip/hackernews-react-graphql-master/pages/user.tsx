import { UserPage } from '../src/pages/user';

export default UserPage;
