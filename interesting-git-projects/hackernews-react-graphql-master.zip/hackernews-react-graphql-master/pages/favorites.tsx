import { FavoritesPage } from '../src/pages/favorites';

export default FavoritesPage;
