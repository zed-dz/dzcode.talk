import { FormatDocPage } from '../src/pages/formatdoc';

export default FormatDocPage;
