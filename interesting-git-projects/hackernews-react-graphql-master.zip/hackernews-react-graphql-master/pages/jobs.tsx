import { JobsPage } from '../src/pages/jobs';

export default JobsPage;
