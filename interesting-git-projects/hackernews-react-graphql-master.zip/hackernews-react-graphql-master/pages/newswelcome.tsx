import { NewsWelcomePage } from '../src/pages/newswelcome';

export default NewsWelcomePage;
