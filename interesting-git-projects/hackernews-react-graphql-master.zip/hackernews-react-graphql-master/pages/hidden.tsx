import { HiddenPage } from '../src/pages/hidden';

export default HiddenPage;
