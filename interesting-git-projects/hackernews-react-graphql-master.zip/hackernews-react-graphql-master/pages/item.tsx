import { ItemPage } from '../src/pages/item';

export default ItemPage;
