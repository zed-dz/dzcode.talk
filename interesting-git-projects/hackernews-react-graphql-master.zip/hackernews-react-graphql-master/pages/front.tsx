import { FrontPage } from '../src/pages/front';

export default FrontPage;
