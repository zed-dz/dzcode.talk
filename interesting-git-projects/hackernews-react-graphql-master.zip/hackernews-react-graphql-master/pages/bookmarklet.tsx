import { BookmarkletPage } from '../src/pages/bookmarklet';

export default BookmarkletPage;
