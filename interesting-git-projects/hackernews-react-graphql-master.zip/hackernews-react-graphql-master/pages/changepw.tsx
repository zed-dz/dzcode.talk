import { ChangePasswordPage } from '../src/pages/changepw';

export default ChangePasswordPage;
