import { NewCommentsPage } from '../src/pages/newcomments';

export default NewCommentsPage;
