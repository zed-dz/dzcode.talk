import { ShowHNRulesPage } from '../src/pages/showhn';

export default ShowHNRulesPage;
