import { AskPage } from '../src/pages/ask';

export default AskPage;
