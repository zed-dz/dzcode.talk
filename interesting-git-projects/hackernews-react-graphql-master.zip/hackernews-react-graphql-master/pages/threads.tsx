import { ThreadsPage } from '../src/pages/threads';

export default ThreadsPage;
