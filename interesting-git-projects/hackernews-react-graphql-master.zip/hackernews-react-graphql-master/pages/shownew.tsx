import { ShowNewPage } from '../src/pages/shownew';

export default ShowNewPage;
