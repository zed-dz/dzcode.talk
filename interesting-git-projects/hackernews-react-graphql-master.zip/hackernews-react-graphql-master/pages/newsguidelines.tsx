import { NewsGuidelinesPage } from '../src/pages/newsguidelines';

export default NewsGuidelinesPage;
