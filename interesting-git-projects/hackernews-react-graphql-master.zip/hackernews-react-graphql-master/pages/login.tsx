import { LoginPage } from '../src/pages/login';

export default LoginPage;
