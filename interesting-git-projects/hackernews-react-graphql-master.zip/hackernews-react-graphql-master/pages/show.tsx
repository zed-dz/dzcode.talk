import { ShowHNPage } from '../src/pages/show';

export default ShowHNPage;
