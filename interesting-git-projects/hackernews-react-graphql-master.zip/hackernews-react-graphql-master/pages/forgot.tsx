import { ForgotPage } from '../src/pages/forgot';

export default ForgotPage;
