import { SecurityPage } from '../src/pages/security';

export default SecurityPage;
