import { NewsFAQPage } from '../src/pages/newsfaq';

export default NewsFAQPage;
