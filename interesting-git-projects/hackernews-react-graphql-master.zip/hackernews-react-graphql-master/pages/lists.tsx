import { ListsPage } from '../src/pages/lists';

export default ListsPage;
