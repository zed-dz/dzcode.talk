import { BestCommentsPage } from '../src/pages/bestcomments';

export default BestCommentsPage;
