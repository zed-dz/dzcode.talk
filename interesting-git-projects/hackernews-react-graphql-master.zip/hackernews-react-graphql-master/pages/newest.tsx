import { NewestPage } from '../src/pages/newest';

export default NewestPage;
