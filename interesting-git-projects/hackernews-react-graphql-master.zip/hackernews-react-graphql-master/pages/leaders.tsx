import { LeadersPage } from '../src/pages/leaders';

export default LeadersPage;
