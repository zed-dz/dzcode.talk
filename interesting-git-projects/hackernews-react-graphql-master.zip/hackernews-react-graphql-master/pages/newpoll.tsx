import { NewPollPage } from '../src/pages/newpoll';

export default NewPollPage;
