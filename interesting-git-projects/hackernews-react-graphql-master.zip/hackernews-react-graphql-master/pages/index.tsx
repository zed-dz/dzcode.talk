import { IndexPage } from '../src/pages/index';

export default IndexPage;
