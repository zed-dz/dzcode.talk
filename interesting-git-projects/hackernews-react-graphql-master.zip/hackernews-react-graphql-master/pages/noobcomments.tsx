import { NoobCommentsPage } from '../src/pages/noobcomments';

export default NoobCommentsPage;
