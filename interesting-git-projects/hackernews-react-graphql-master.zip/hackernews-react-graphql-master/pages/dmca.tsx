import { DMCAPage } from '../src/pages/dmca';

export default DMCAPage;
