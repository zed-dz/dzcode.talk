import { ActivePage } from '../src/pages/active';

export default ActivePage;
