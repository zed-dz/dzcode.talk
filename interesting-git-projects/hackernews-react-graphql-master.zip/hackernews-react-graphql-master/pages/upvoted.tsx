import { UpvotedPage } from '../src/pages/upvoted';

export default UpvotedPage;
