====================
Additional Tutorials
====================

Learn How to Use Cookiecutter
-----------------------------

* :doc:`tutorial1` by `@audreyr`_


Create Your Very Own Cookiecutter Project Template
--------------------------------------------------

* :doc:`tutorial2` by `@audreyr`_

* `Project Templates Made Easy`_ by `@pydanny`_

* Cookiedozer Tutorials by `@hackebrot`_

  * Part 1: `Create your own Cookiecutter template`_
  * Part 2: `Extending our Cookiecutter template`_
  * Part 3: `Wrapping up our Cookiecutter template`_


.. _`Project Templates Made Easy`: http://www.pydanny.com/cookie-project-templates-made-easy.html

.. _`Create your own Cookiecutter template`: https://raphael.codes/blog/create-your-own-cookiecutter-template/
.. _`Extending our Cookiecutter template`: https://raphael.codes/blog/extending-our-cookiecutter-template/
.. _`Wrapping up our Cookiecutter template`: https://raphael.codes/blog/wrapping-up-our-cookiecutter-template/

.. _`@audreyr`: https://github.com/audreyr
.. _`@pydanny`: https://github.com/pydanny
.. _`@hackebrot`: https://github.com/hackebrot
