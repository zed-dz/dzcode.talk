Empty, just like the hooks we are testing.
