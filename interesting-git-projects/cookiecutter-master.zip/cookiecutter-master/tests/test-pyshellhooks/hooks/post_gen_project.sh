#!/bin/bash

echo 'post generation hook';
touch 'shell_post.txt'
