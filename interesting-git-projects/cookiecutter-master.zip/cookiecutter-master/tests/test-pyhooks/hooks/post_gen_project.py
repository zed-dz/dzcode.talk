#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function

print('pre generation hook')
f = open('python_post.txt', 'w')
f.close()
