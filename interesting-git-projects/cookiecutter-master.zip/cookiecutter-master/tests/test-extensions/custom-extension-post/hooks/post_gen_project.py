# -*- coding: utf-8 -*-
# flake8: noqa

print('{% hello cookiecutter.name %}')
