"""Empty __init__.py file to signal Python this directory is a package."""

from __future__ import print_function, division, absolute_import
from fontTools.misc.py23 import *
