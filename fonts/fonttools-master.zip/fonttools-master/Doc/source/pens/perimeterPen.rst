############
perimeterPen
############

.. automodule:: fontTools.pens.perimeterPen
   :members:
   :undoc-members:
