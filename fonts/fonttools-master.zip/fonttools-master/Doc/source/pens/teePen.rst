######
teePen
######

.. automodule:: fontTools.pens.teePen
   :members:
   :undoc-members:
