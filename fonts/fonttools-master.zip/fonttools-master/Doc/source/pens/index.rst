####
pens
####

.. toctree::
   :maxdepth: 1

   basePen
   boundsPen
   pointInsidePen
   filterPen
   transformPen
   t2CharStringPen
   statisticsPen
   recordingPen
   teePen
   areaPen
   perimeterPen
