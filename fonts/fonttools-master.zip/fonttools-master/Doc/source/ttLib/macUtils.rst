########
macUtils
########

.. automodule:: fontTools.ttLib.macUtils
   :members:
   :undoc-members:
