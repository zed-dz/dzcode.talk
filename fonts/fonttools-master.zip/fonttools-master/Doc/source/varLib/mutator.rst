#######
mutator
#######

.. automodule:: fontTools.varLib.mutator
   :members:
   :undoc-members:
