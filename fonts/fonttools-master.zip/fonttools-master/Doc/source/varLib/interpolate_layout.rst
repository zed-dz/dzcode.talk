##################
interpolate_layout
##################

.. automodule:: fontTools.varLib.interpolate_layout
   :members:
   :undoc-members:
