#########
xmlWriter
#########

.. automodule:: fontTools.misc.xmlWriter
   :members:
   :undoc-members:
