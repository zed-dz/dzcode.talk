#############
classifyTools
#############

.. automodule:: fontTools.misc.classifyTools
   :members:
   :undoc-members:
